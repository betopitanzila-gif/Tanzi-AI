# AFPG TransitionHub - Phase 1

A working React/Vite source-code project for tracking AFPG acquisition provider migration work.

## Features
- Separate acquisition workspaces: Praescius, CPW, Chalmers, and future acquisitions
- Add providers dynamically
- Upload Excel spreadsheets (`.xlsx`, `.xls`, `.csv`) into the selected acquisition
- Track old dealer code, old adviser codes, new dealer code, and new adviser/corporate code
- Pipeline stages based on the real AFPG acquisition workflow
- Staff access checklist
- Local browser saving using localStorage
- Export backup JSON

## How to run locally
1. Install Node.js from https://nodejs.org/
2. Open this folder in Visual Studio Code
3. Open Terminal
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL shown in the terminal.

## How to build
```bash
npm run build
```

The production files will be created in the `dist` folder.

## How to put it on GitHub
1. Create a new GitHub repository called `afpg-transitionhub`
2. Upload all files from this folder
3. Commit changes
4. Optional: connect to Netlify/Vercel for hosting

## Notes
This Phase 1 version saves to the browser on the computer being used. Phase 2 can add a proper backend/database such as SQLite, SQL Server, or SharePoint storage.
