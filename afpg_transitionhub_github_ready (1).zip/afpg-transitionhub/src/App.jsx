import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import * as XLSX from 'xlsx';
import {Plus, Upload, Trash2, Download, Search, CheckCircle2} from 'lucide-react';
import './style.css';

const stages = [
  'Acceptance Letter Sent','Release Letter Sent','Waiting for New Codes','Follow Up','New Codes Received','Portal Registration','Dealer Group Access','Staff Access','Client Transfers','Validation','Completed'
];

const defaultStaff = ['Tanzi','Debbie','Sarah','Liam','Connor','Josie','Dusan','Sharyn','Tanya'];
const chalmersProviders = ['HUB24','KeyInvest','BT PANORAMA','Australian Super','Austock','AWARE SUPER','MLC INVESTMENTS','NAVIGATOR AUSTRALIA LTD','HESTA','Netwealth','Macquarie','CFS','Zurich','TAL','AIA','ClearView','MetLife','OnePath','Mason Stevens','AMP','Colonial First State','IOOF','Praemium','Asgard','Australian Unity','CareSuper','Hostplus','Rest','UniSuper','Vanguard','North','Expand'];

function blankProvider(name=''){
  return {id: crypto.randomUUID(), name, oldDealer:'', oldAdviserCodes:'', newDealer:'', newCorporateCode:'', stage:stages[0], owner:'', notes:'', staffAccess:{}, portalRegistered:false, createdAt:new Date().toISOString()};
}

const seed = [
  {id: crypto.randomUUID(), name:'Praescius', status:'Active', providers:[blankProvider('Macquarie'), blankProvider('CFS'), blankProvider('HUB24')]},
  {id: crypto.randomUUID(), name:'CPW', status:'Active', providers:[blankProvider('Macquarie'), blankProvider('BT Panorama')]},
  {id: crypto.randomUUID(), name:'Chalmers', status:'Active', providers: chalmersProviders.map(blankProvider)}
];

function normalise(s){return String(s||'').trim();}
function findHeader(headers, options){ const low=headers.map(h=>String(h).toLowerCase()); return options.find(o=>low.some(h=>h.includes(o.toLowerCase()))); }
function getVal(row, headers, patterns){
  const key = headers.find(h => patterns.some(p => String(h).toLowerCase().includes(p.toLowerCase())));
  return key ? normalise(row[key]) : '';
}

function App(){
  const [data,setData] = useState(()=>{try{return JSON.parse(localStorage.getItem('afpg_transitionhub_v1')) || seed}catch{return seed}});
  const [selectedId,setSelectedId] = useState(()=>data[0]?.id);
  const [tab,setTab] = useState('providers');
  const [search,setSearch] = useState('');
  const selected = data.find(a=>a.id===selectedId) || data[0];
  useEffect(()=>localStorage.setItem('afpg_transitionhub_v1', JSON.stringify(data)),[data]);
  useEffect(()=>{ if(!selected && data[0]) setSelectedId(data[0].id); },[data,selected]);

  function updateSelected(fn){ setData(ds=>ds.map(a=>a.id===selected.id ? fn(a) : a)); }
  function addAcq(){ const name=prompt('Acquisition name'); if(!name) return; const n={id:crypto.randomUUID(), name, status:'Active', providers:[]}; setData([...data,n]); setSelectedId(n.id); }
  function addProvider(){ const name=prompt('Provider name'); if(!name) return; updateSelected(a=>({...a, providers:[...a.providers, blankProvider(name)]})); }
  function deleteProvider(id){ updateSelected(a=>({...a, providers:a.providers.filter(p=>p.id!==id)})); }
  function updateProvider(id,patch){ updateSelected(a=>({...a, providers:a.providers.map(p=>p.id===id?{...p,...patch}:p)})); }
  function exportJson(){ const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='afpg-transitionhub-backup.json'; a.click(); }
  function resetDemo(){ if(confirm('Reset all app data?')) {localStorage.removeItem('afpg_transitionhub_v1'); location.reload();} }
  async function importExcel(e){
    const file=e.target.files[0]; if(!file) return;
    const buf=await file.arrayBuffer(); const wb=XLSX.read(buf); let rows=[];
    wb.SheetNames.forEach(s=>{ rows.push(...XLSX.utils.sheet_to_json(wb.Sheets[s],{defval:''})); });
    const imported=[];
    rows.forEach(row=>{
      const headers=Object.keys(row);
      let name = getVal(row, headers, ['provider','platform','description','product','fund','company']);
      let oldDealer = getVal(row, headers, ['old dealer','existing dealer','dealer code']);
      let oldAdviserCodes = getVal(row, headers, ['old adviser','existing adviser','adviser code','adviser codes']);
      let newDealer = getVal(row, headers, ['new dealer']);
      let newCorporateCode = getVal(row, headers, ['new adviser','corporate code','new corporate']);
      if(!name){
        const vals=Object.values(row).map(normalise).filter(Boolean);
        if(vals.length===1) name=vals[0];
      }
      if(name && !/provider|description|adviser code/i.test(name)) imported.push({...blankProvider(name), oldDealer, oldAdviserCodes, newDealer, newCorporateCode});
    });
    if(!imported.length){ alert('No providers detected. Check the spreadsheet has a provider/platform/description column.'); return; }
    updateSelected(a=>{
      const byName=new Map(a.providers.map(p=>[p.name.toLowerCase(),p]));
      imported.forEach(p=>{
        const key=p.name.toLowerCase();
        if(byName.has(key)) byName.set(key,{...byName.get(key), ...Object.fromEntries(Object.entries(p).filter(([k,v])=>v && k!=='id'))});
        else byName.set(key,p);
      });
      return {...a, providers:Array.from(byName.values())};
    });
    alert(`${imported.length} providers imported/updated into ${selected.name}.`); e.target.value='';
  }

  const filteredProviders = (selected?.providers||[]).filter(p=>[p.name,p.oldDealer,p.oldAdviserCodes,p.newDealer,p.newCorporateCode,p.stage,p.owner,p.notes].join(' ').toLowerCase().includes(search.toLowerCase()));
  const completed=(selected?.providers||[]).filter(p=>p.stage==='Completed').length;
  const pct=selected?.providers?.length?Math.round(completed/selected.providers.length*100):0;

  return <div className="app">
    <aside><h1>AFPG<br/>TransitionHub</h1><button className="primary" onClick={addAcq}><Plus size={16}/> New Acquisition</button><nav>{data.map(a=><button key={a.id} className={a.id===selected?.id?'active':''} onClick={()=>setSelectedId(a.id)}>{a.name}<span>{a.providers.length}</span></button>)}</nav><button className="ghost" onClick={exportJson}><Download size={15}/> Export backup</button><button className="ghost danger" onClick={resetDemo}><Trash2 size={15}/> Reset demo</button></aside>
    <main>{selected&&<>
      <header><div><h2>{selected.name}</h2><p>{selected.providers.length} providers • {pct}% complete</p></div><div className="progress"><div style={{width:pct+'%'}}/></div></header>
      <div className="cards"><Card title="Providers" value={selected.providers.length}/><Card title="Completed" value={completed}/><Card title="Waiting for Codes" value={selected.providers.filter(p=>p.stage==='Waiting for New Codes').length}/><Card title="Client Transfers" value={selected.providers.filter(p=>p.stage==='Client Transfers').length}/></div>
      <div className="tabs"><button className={tab==='providers'?'on':''} onClick={()=>setTab('providers')}>Providers</button><button className={tab==='pipeline'?'on':''} onClick={()=>setTab('pipeline')}>Pipeline</button><button className={tab==='staff'?'on':''} onClick={()=>setTab('staff')}>Staff Access</button></div>
      <section className="toolbar"><button className="primary" onClick={addProvider}><Plus size={16}/> Add Provider</button><label className="upload"><Upload size={16}/> Upload spreadsheet<input type="file" accept=".xlsx,.xls,.csv" onChange={importExcel}/></label><div className="search"><Search size={15}/><input placeholder="Search provider, code, owner, stage..." value={search} onChange={e=>setSearch(e.target.value)}/></div></section>
      {tab==='providers'&&<ProviderTable providers={filteredProviders} updateProvider={updateProvider} deleteProvider={deleteProvider}/>} 
      {tab==='pipeline'&&<Pipeline providers={filteredProviders} updateProvider={updateProvider}/>} 
      {tab==='staff'&&<Staff providers={filteredProviders} updateProvider={updateProvider}/>} 
    </>}</main>
  </div>;
}
function Card({title,value}){return <div className="card"><p>{title}</p><strong>{value}</strong></div>}
function ProviderTable({providers,updateProvider,deleteProvider}){return <div className="tableWrap"><table><thead><tr><th>Provider</th><th>Old Dealer</th><th>Old Adviser Codes</th><th>New Dealer</th><th>New Corporate/Adviser Code</th><th>Stage</th><th>Owner</th><th>Notes</th><th></th></tr></thead><tbody>{providers.map(p=><tr key={p.id}><td><input value={p.name} onChange={e=>updateProvider(p.id,{name:e.target.value})}/></td><td><input value={p.oldDealer} onChange={e=>updateProvider(p.id,{oldDealer:e.target.value})}/></td><td><textarea value={p.oldAdviserCodes} onChange={e=>updateProvider(p.id,{oldAdviserCodes:e.target.value})}/></td><td><input value={p.newDealer} onChange={e=>updateProvider(p.id,{newDealer:e.target.value})}/></td><td><input value={p.newCorporateCode} onChange={e=>updateProvider(p.id,{newCorporateCode:e.target.value})}/></td><td><select value={p.stage} onChange={e=>updateProvider(p.id,{stage:e.target.value})}>{stages.map(s=><option key={s}>{s}</option>)}</select></td><td><input value={p.owner} onChange={e=>updateProvider(p.id,{owner:e.target.value})}/></td><td><textarea value={p.notes} onChange={e=>updateProvider(p.id,{notes:e.target.value})}/></td><td><button className="icon danger" onClick={()=>deleteProvider(p.id)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}
function Pipeline({providers,updateProvider}){return <div className="pipeline">{stages.map(stage=><div className="lane" key={stage}><h3>{stage}</h3>{providers.filter(p=>p.stage===stage).map(p=><div className="ticket" key={p.id}><b>{p.name}</b><p>{p.oldDealer||'Old dealer TBC'} → {p.newDealer||'New dealer TBC'}</p><select value={p.stage} onChange={e=>updateProvider(p.id,{stage:e.target.value})}>{stages.map(s=><option key={s}>{s}</option>)}</select></div>)}</div>)}</div>}
function Staff({providers,updateProvider}){return <div className="staffGrid">{providers.map(p=><div className="staffCard" key={p.id}><h3>{p.name}</h3>{defaultStaff.map(st=><label key={st}><input type="checkbox" checked={!!p.staffAccess?.[st]} onChange={e=>updateProvider(p.id,{staffAccess:{...(p.staffAccess||{}),[st]:e.target.checked}})}/>{st}</label>)}{Object.values(p.staffAccess||{}).every(Boolean)&&<p className="done"><CheckCircle2 size={15}/> staff access complete</p>}</div>)}</div>}

createRoot(document.getElementById('root')).render(<App/>);
